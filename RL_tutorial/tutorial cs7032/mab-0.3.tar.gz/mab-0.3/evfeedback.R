## Some code for investigating exploitation/exploration dilemman in
## MAB settings
##
## (c) 2007 S. Luz (luzs@acm.org)

## run evaluative feedback for different values of e on ntasks n-armed
## testbeds and plot results in terms of average reward over
## time-steps (plays) and % correct action (a*) selected over plays.
##
## NB: for faster runs but less smooth curves try setting ntasks to a smaller value
runExperiment1 <- function (ntasks=1000, nplays=1000, n=10, es=c(0, 0.01, 0.1), cols=c(1,2,3)){
  nbandits <- vector("list", ntasks)
  x11()   ## make new display device for avg results plot
  avgdev <- dev.cur()
  x11()   ## make new display device for pct a*  plot
  pcadev <- dev.cur()
  li <- 0
  for (i in 1:ntasks)
    nbandits[[i]] <- makeNArmedBanditTask(n=n,s=nplays)
  for (e in es) {     #different values for epsilon
    col <- cols[(li <- li+1)]
    rewards <- rep(0,nplays) ## cumulative reward
    nastar <- rep(0,nplays)  ## number of optimal selections
    for (i in 1:ntasks) {
      d <- nbandits[[i]]
      actions <- evalLearn(d, e=e)   # actions selected via evaluative 'learning'
      rewindex <- cbind(1:nplays,actions) ## index of rewards
      rewards <- rewards + d[rewindex]
      ##acstars <- max.col(d)          # optimal actions: for each play \arg_a\max Q(a)
      acstar <- which.max(apply(d,2,mean)) ## global optimal action
                                           ## \arg_a\max Q*(a)
                                           ## (produces the % optimal
                                           ## actions shown in the notes )

      nastar <- nastar + (actions==acstar) ## number of agent-chosen actions that match a*
    }
    arew <- rewards/ntasks
    pctastar <- nastar/ntasks
    if (col > 1) {
      dev.set(pcadev)
      lines(pctastar*100, col=col)
      dev.set(avgdev)
      lines(arew, col=col)
    }
    else {
      dev.set(pcadev)
      plot(pctastar*100, ylim=c(0,100), ylab="% optimal action", xlab="plays",
           type='l', col=col, axes=F)##, ylim=c(min(nbandits[[1]]),max(nbandits[[1]])))
      axis(1); axis(2)
      dev.set(avgdev)
      plot(arew, ylab="average reward", xlab="plays", axes=F,
           type='l', col=col, ylim=c(0,.7*max(nbandits[[1]])))
      axis(1); axis(2)
    } 
  }
  dev.set(pcadev)
  legend('topright', col=cols, lty=1,
         legend=sapply(es,function(e)eval(substitute(expression(epsilon==e), list(e=e)))))
  dev.set(avgdev)
  legend('topright', col=cols, lty=1,
         legend=sapply(es,function(e)eval(substitute(expression(epsilon==e), list(e=e)))))
}

### basic functions
####################
makeNArmedBanditTask <- function(n=10, s=1000){
  qtrue <- rnorm(n)  # mean rewards sampled from a nomal dist mean=0, var=1 (by default)
  r <- matrix(nrow=s,ncol=n) # matrix to store rewards (actions denoted by indices)
  for (i in 1:n){
    r[,i] <- rnorm(s,mean=qtrue[i]) # rewards for 'arm' i, from a nomal dist mean=q*_i, var=0
  }
  print(qtrue)
  r
}

## 'learn' to evaluate feedback for dset (e.g. the 10-armed dataset)
## by iterating up to tmax times (e.g. 1000 times as in [Sutton &
## Barto, 98])
evalLearn <- function(dset, ## n-armed dataset
                      e=0, ## greed
                      tmax=dim(dset)[1], ## number of plays
                      q0=0 ## Q_0: initial reward estimate (default: pessimistic) 
                      ){
  n <- dim(dset)[2]
  r <- rep(q0,n) # Q matrix: store rewards per action
  k <- rep(0,n)  # keep track of number of rewards received so far per action
  actions <- vector(mode='numeric', length=tmax) #�record actions chosen
  for (i in 1:tmax){
    a <- selectAction(r, e=e)
    actions[i] <- a
    k[a] <- k[a]+1
    r[a] <- updateEstimate(r[a],dset[i,a],1/k[a])
  }
  actions
}

## 
selectAction <- function(avgr, e=0) {
  n <- length(avgr) # number of arms (cols in r)
  if (e>0 && sample(c(T,F),1,prob=c(e,1-e))) { # exploit if e > 0 and chance allows
    return(sample(1:n,1))
  }
  else {
    ties <- which(avgr == max(avgr))
    if (length(ties)>1)
      return(sample(ties, 1))
    else
      return(ties)
  }
}

updateEstimate <- function(old, target, step) {
  old + step * (target - old)
}
